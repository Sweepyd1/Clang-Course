

void printRectangle(int h_limit, int v_limit);
void drawDiagonal(int size);
void drawHouse(int width, int height);
void printCircle(int radius);
void rainAnimation(int width, int height, int drops);

