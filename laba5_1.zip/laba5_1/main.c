#include <stdio.h>
#include "draw.h"

int main() {
    printRectangle(5,7);
  

    return 0;
}
